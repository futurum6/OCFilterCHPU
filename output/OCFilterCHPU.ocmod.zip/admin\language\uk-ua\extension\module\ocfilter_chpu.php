<?php
$_['heading_title']    = 'OCFilter ЧПУ';
$_['text_extension']   = 'Модули';
$_['text_success']     = 'Настройки модуля OCFilter ЧПУ успешно сохранены!';
$_['text_edit']        = 'Редактирование модуля OCFilter ЧПУ';
$_['text_enabled']     = 'Включено';
$_['text_disabled']    = 'Отключено';
$_['entry_status']     = 'Статус';
$_['entry_url_format'] = 'Формат URL';
$_['entry_separator']  = 'Разделитель';
$_['help_url_format']  = 'Использовать ID или keyword для генерации URL<br/><b>keyword</b> - /brand-samsung/<br/><b>id</b> - /1-2/';
$_['help_separator']   = 'Разделитель между названием фильтра и значением (по умолчанию: -)';
$_['error_permission'] = 'У вас недостаточно прав для изменения модуля OCFilter ЧПУ!';
?>