<?php
$_['heading_title']    = 'OCFilter SEO URL';
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'OCFilter SEO URL module settings successfully saved!';
$_['text_edit']        = 'Edit OCFilter SEO URL module';
$_['text_enabled']     = 'Enabled';
$_['text_disabled']    = 'Disabled';
$_['text_home']        = 'Home';
$_['entry_status']     = 'Status';
$_['button_save']      = 'Save';
$_['button_cancel']    = 'Cancel';
$_['error_permission'] = 'You do not have permission to modify OCFilter SEO URL module!';