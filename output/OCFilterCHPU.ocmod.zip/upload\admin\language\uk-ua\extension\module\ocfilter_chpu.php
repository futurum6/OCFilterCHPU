<?php
$_['heading_title']    = 'OCFilter ЧПУ';
$_['text_extension']   = 'Модули';
$_['text_success']     = 'Настройки модуля OCFilter ЧПУ успешно сохранены!';
$_['text_edit']        = 'Редактирование модуля OCFilter ЧПУ';
$_['text_enabled']     = 'Включено';
$_['text_disabled']    = 'Отключено';
$_['text_home']        = 'Главная';
$_['entry_status']     = 'Статус';
$_['button_save']      = 'Сохранить';
$_['button_cancel']    = 'Отмена';
$_['error_permission'] = 'У вас недостаточно прав для изменения модуля OCFilter ЧПУ!';